## Prerequisites

- npm install
- gem install premailer

## Tasks

- npm run build (default task will build new inlines email templates)
- npm start (builds on source HTML, text, or CSS change)

## Result

Assembled email templates will be in `dist/` and final
inlined templates will be in `../public/emails/`
