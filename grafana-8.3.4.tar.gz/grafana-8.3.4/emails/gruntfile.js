module.exports = function (grunt) {
  // load grunt config
  require('load-grunt-config')(grunt);
};
