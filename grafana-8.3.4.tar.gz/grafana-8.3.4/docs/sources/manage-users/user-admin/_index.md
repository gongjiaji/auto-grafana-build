+++
title = "User account tasks"
weight = 400
+++

# User account tasks

Grafana allows you to manage certain aspects of your user account, including the user name, email, and password.

You can also view important aspects of your account, such as the organizations and roles assigned and the Grafana sessions associated with the account.
