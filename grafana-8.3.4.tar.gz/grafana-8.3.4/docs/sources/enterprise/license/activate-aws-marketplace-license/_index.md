+++
title = "Activate a Grafana Enterprise license purchased through AWS Marketplace"
description = "Activate Enterprise license purchased through AWS Marketplace"
keywords = ["grafana", "aws", "marketplace", "enterprise", "license"]
weight = 400
+++

# Activate a Grafana Enterprise license purchased through AWS Marketplace

AWS Marketplace is a convenient place for AWS customers to buy and manage a license for Grafana Enterprise versions 8.3.0 and later.

{{< section >}}
