# Bundled Plugins

Bundled plugins are built as true plugins, and managed by the grafana install.

TODO: the packaging system should move all `dist` items to the root and remove sources.
