Right now Tempo is before stable release so this uses :latest tag which means there can be changes depending on when
you pull the image.

For adding some traces easily you can run Loki block and enable tracing (see ../loki/README.md)
